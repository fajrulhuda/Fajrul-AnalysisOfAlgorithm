#Nama: Fajrul Huda Ash Shiddiq
#NIM: 23343063

def russian_peasant(a, b):
    hasil = 0
    langkah = []  # Menyimpan langkah-langkah untuk debugging
    
    while b > 0:
        langkah.append((a, b, hasil))  # Simpan langkah sebelum perhitungan
        
        if b & 1:  # Jika b ganjil, tambahkan a ke hasil
            hasil += a
        
        a <<= 1  # Kalikan a dengan 2 (left shift)
        b >>= 1  # Bagi b dengan 2 (right shift)
    
    langkah.append((a, b, hasil))  # Simpan langkah terakhir
    return hasil, langkah

# Fungsi untuk mencetak langkah-langkah
def tampil_langkah(langkah):
    print("Langkah-langkah perhitungan Russian Peasant Algorithm:")
    print("--------------------------------------------------")
    print("|    a    |    b    |   hasil   |")
    print("--------------------------------------------------")
    for a, b, hasil in langkah:
        print(f"| {a:7} | {b:7} | {hasil:9} |")
    print("--------------------------------------------------")

# Contoh penggunaan
bilangan1 = 37
bilangan2 = 19
hasil, langkah = russian_peasant(bilangan1, bilangan2)
print(f"Hasil perkalian {bilangan1} dan {bilangan2} menggunakan Russian Peasant Algorithm adalah: {hasil}\n")

# Cetak langkah-langkahnya
tampil_langkah(langkah)
